part of 'countrylist_cubit.dart';

@immutable
abstract class CountrylistState {}

class CountrylistInitial extends CountrylistState {
}
