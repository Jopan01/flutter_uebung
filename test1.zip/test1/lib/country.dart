class Country {
  String name;
  String image;

  Country(this.name, this.image);
}
