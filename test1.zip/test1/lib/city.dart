class City {
  String name;
  String image;

  City(this.name, this.image);
}
